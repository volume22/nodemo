package com.example.nodemo.controller.dto;

import lombok.Getter;

@Getter
public class CategoryCreatedto {
    private String name;
}
