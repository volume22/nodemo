package com.example.nodemo.controller.dto;

import lombok.Getter;

@Getter
public class CoffeeCreateDto {
    private String name;
    private Integer quantity;
    private Integer price;
}
