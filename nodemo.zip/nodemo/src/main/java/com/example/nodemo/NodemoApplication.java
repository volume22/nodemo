package com.example.nodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NodemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(NodemoApplication.class, args);
    }

}
