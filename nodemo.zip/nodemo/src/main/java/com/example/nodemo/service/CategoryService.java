package com.example.nodemo.service;

import com.example.nodemo.model.Category;

public interface CategoryService {
    Long createCategory(String name);
}
