package com.example.nodemo.controller.dto;

import lombok.Getter;

@Getter
public class OrderCreatedto {
private Integer price;
}
